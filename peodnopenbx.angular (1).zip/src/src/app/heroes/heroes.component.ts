import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-heroes',
  templateUrl: './heroes.component.html',
  styleUrls: ['./heroes.component.css']
})
export class HeroesComponent implements OnInit {
  todaydate = new Date();
  month = this.todaydate.getMonth();
  year = this.todaydate.getFullYear();
     days = [];

  Dropdown: string[] = ["Clear skies", "Overcast", "Partly Sunny", "Suny", "Partly cloudy", "chance of rain", " Cloudy", "chance of showers", "zxcvbnm"]
  constructor() { }

  ngOnInit() {
  


function getDaysInMonth(month, year) {
  var date = new Date(year, month, 1);
  while (date.getMonth() === month) {
    this.days.push(new Date(date));
    date.setDate(date.getDate() + 1);
  }
  return this.days;
}}
}
