
import { Pipe } from '@angular/core';
@Pipe({
  name:"default"
})
class DefaultPipe { 
  
}