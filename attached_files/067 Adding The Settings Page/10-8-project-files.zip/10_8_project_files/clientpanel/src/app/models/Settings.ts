export interface Settings{
    allowRegistration?:boolean;
    disableBalanceOnAdd?:boolean;
    disableBalanceOnEdit?:boolean;
}