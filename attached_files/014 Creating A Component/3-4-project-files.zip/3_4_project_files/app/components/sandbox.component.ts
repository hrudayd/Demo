import { Component } from '@angular/core';

@Component({
    selector:'sandbox',
    template:`<h1>Hello World</h1>`
})

export class SandboxComponent{

}