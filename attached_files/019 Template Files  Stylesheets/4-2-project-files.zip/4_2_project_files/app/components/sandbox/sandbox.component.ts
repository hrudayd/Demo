import { Component } from '@angular/core';

@Component({
    selector:'sandbox',
    templateUrl:`./sandbox.component.html`,
    styleUrls:['./sandbox.component.css']
    /*
    styles: [`
        .special{
            color:green;
            font-size:20px;
            text-transform:uppercase
        }
    `]
    */
})

export class SandboxComponent{

}